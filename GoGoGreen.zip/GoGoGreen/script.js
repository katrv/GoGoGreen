window.onload = function () {
    // Initialize your game when the window is loaded
  
    const grid = document.getElementById('grid');
    let earthHealth = 100;
  
    function createGrid(rows, cols) {
      for (let i = 0; i < rows * cols; i++) {
        const cell = document.createElement('div');
        cell.classList.add('cell');
        grid.appendChild(cell);
      }
    }
  
    function clearCell(cell) {
      cell.classList.remove('tree', 'animal', 'factory', 'building', 'house');
    }
  
    function adjustHealth(change) {
      earthHealth = Math.max(0, Math.min(100, earthHealth + change));
      updateHealthBar();
    }
  
    function updateHealthBar() {
      const fill = document.getElementById('health-fill');
      fill.style.width = earthHealth + '%';
  
      let status = document.getElementById('health-status');
      if (earthHealth > 70) {
        fill.style.backgroundColor = 'green';
        status.textContent = "Earth is happy! 🌍";
      } else if (earthHealth > 30) {
        fill.style.backgroundColor = 'orange';
        status.textContent = "Earth is okay... let's plant more trees! 🌳";
      } else {
        fill.style.backgroundColor = 'red';
        status.textContent = "Oh no! Earth needs help! 🚨";
      }
    }
  
    function placeItem(type) {
      const cells = Array.from(document.querySelectorAll('.cell'));
      const emptyCells = cells.filter(cell =>
        !cell.classList.contains('tree') &&
        !cell.classList.contains('animal') &&
        !cell.classList.contains('house') &&
        !cell.classList.contains('factory') &&
        !cell.classList.contains('building')
      );
  
      if (emptyCells.length === 0) return;
  
      const randomCell = emptyCells[Math.floor(Math.random() * emptyCells.length)];
      clearCell(randomCell);
  
      if (type === 'positive') {
        const item = Math.random() < 0.5 ? 'tree' : 'animal';
        randomCell.classList.add(item);
        adjustHealth(item === 'tree' ? 5 : 7);
        showFact(item === 'tree' ? "Trees clean the air!" : "You added a forest friend!");
      } else {
        const negativeItems = ['house', 'factory', 'building'];
        const item = negativeItems[Math.floor(Math.random() * negativeItems.length)];
        randomCell.classList.add(item);
        const penalty = item === 'factory' ? -15 : item === 'house' ? -10 : -5;
        adjustHealth(penalty);
        const facts = {
          house: "Houses are great—but don’t forget the trees!",
          factory: "Factories cause pollution!",
          building: "Cities are growing—let’s keep nature too!"
        };
        showFact(facts[item]);
      }
    }
  
    function showFact(text) {
      const box = document.getElementById('fact-box');
      box.textContent = text;
      setTimeout(() => { box.textContent = ''; }, 4000);
    }
  
    const questions = [
      {
        question: "What gas do trees absorb?",
        choices: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Helium"],
        correct: "Carbon Dioxide"
      },
      {
        question: "Which energy source is renewable?",
        choices: ["Coal", "Natural Gas", "Wind", "Oil"],
        correct: "Wind"
      },
      {
        question: "What can you do to reduce plastic waste?",
        choices: ["Use paper once", "Buy more plastic", "Use reusable bags", "Burn trash"],
        correct: "Use reusable bags"
      },
      {
        question: "Which is good for biodiversity?",
        choices: ["Cutting all trees", "Planting native species", "Paving forests", "Building factories"],
        correct: "Planting native species"
      },
      {
        question: "Why should we save water?",
        choices: ["Because it's fun", "Because it's free", "Because clean water is limited", "Because it's everywhere"],
        correct: "Because clean water is limited"
      },
      {
        question: "What is composting?",
        choices: ["Throwing trash in ocean", "Letting organic waste decompose", "Burning waste", "Burying plastic"],
        correct: "Letting organic waste decompose"
      },
      {
        question: "Which action reduces air pollution?",
        choices: ["Driving alone every day", "Planting trees", "Using coal", "Burning leaves"],
        correct: "Planting trees"
      },
      {
        question: "What is a carbon footprint?",
        choices: ["A shoe print", "The cost of carbon", "Amount of CO2 you produce", "Carbon sticker"],
        correct: "Amount of CO2 you produce"
      },
      {
        question: "How can you save energy at home?",
        choices: ["Leave lights on", "Use LED bulbs", "Use old appliances", "Keep windows open"],
        correct: "Use LED bulbs"
      },
      {
        question: "Why recycle paper?",
        choices: ["It's fun", "It grows trees", "It saves trees and water", "It makes more trash"],
        correct: "It saves trees and water"
      },
    ];
  
    let questionIndex = 0;
  
    function askNextQuestion() {
      if (questionIndex >= questions.length) {
        document.getElementById('question-box').innerHTML = "<p>You've finished the game! 🎉</p>";
        return;
      }
  
      const q = questions[questionIndex];
      document.getElementById('question-text').textContent = q.question;
  
      const choicesDiv = document.getElementById('choices');
      choicesDiv.innerHTML = '';
  
      q.choices.forEach(choice => {
        const btn = document.createElement('button');
        btn.textContent = choice;
        btn.onclick = () => checkAnswer(choice, q.correct);
        choicesDiv.appendChild(btn);
      });
  
      document.getElementById('feedback').textContent = '';
    }
  
    function checkAnswer(selected, correct) {
      const feedback = document.getElementById('feedback');
  
      if (selected === correct) {
        feedback.textContent = "✅ Correct!";
        placeItem('positive');
      } else {
        feedback.textContent = `❌ Incorrect. Correct answer: ${correct}`;
        placeItem('negative');
      }
  
      questionIndex++;
      setTimeout(askNextQuestion, 2000);
    }
  
    // Start game
    createGrid(8, 15);
    updateHealthBar();
    askNextQuestion();  // Start the first question
  };
  